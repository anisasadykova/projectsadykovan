def extract_data(result):
    """
    Извлекает основные текстовые ответы
    из JSON-ответа Wolfram Alpha.
    """

    if not result.get("success"):
        return {
            "query": result.get("query"),
            "answer": None,
            "error": result.get("error")
        }

    data = result.get("data", {})

    query_result = data.get("queryresult", {})

    extracted = {
        "query": result.get("query"),
        "success": query_result.get("success"),
        "answer": None
    }

    pods = query_result.get("pods", [])

    answers = []

    for pod in pods:
        subpods = pod.get("subpods", [])

        for subpod in subpods:
            plaintext = subpod.get("plaintext")

            if plaintext:
                answers.append({
                    "pod": pod.get("title"),
                    "text": plaintext
                })

    extracted["answer"] = answers

    return extracted