import os
from dotenv import load_dotenv

load_dotenv()

WOLFRAM_APP_ID = os.getenv("WOLFRAM_APP_ID")

if not WOLFRAM_APP_ID:
    raise ValueError("Не найден WOLFRAM_APP_ID в файле .env")