QUERIES = [
    "integrate x^2 sin^3 x dx",
    "population of Russia 2024",
    "molar mass of H2SO4",
    "kinetic energy of 5kg object at 10m/s",
    "distance between Moscow and Saint Petersburg",
    "100 USD to RUB",
    "current time in Kazan",
    "distance to Mars",
    "body mass index 180cm 75kg",
    "translate hello to Russian",

    # Дополнительные запросы
    "square root of 144",
    "capital of France",
    "speed of light",
    "area of circle radius 10",
    "weather in Moscow"
]