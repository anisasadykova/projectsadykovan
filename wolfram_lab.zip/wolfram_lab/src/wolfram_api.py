import requests
import logging

from config import WOLFRAM_APP_ID


API_URL = "https://api.wolframalpha.com/v2/query"


def send_query(query):
    """
    Отправляет запрос в Wolfram Alpha Full Results API
    и получает ответ в формате JSON.
    """

    params = {
        "appid": WOLFRAM_APP_ID,
        "input": query,
        "output": "json",
        "format": "plaintext"
    }

    try:
        response = requests.get(
            API_URL,
            params=params,
            timeout=30
        )

        response.raise_for_status()

        data = response.json()

        logging.info(f"Успешный запрос: {query}")

        return {
            "query": query,
            "success": True,
            "data": data
        }

    except requests.exceptions.RequestException as error:
        logging.error(
            f"Ошибка сети/API для запроса '{query}': {error}"
        )

        return {
            "query": query,
            "success": False,
            "error": str(error)
        }

    except ValueError as error:
        logging.error(
            f"Ошибка обработки JSON для запроса '{query}': {error}"
        )

        return {
            "query": query,
            "success": False,
            "error": "Ответ API не является корректным JSON"
        }