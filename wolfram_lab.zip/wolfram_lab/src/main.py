import json
import logging
import os

from queries import QUERIES
from wolfram_api import send_query
from parser import extract_data


BASE_DIR = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

DATA_DIR = os.path.join(BASE_DIR, "data")
LOGS_DIR = os.path.join(BASE_DIR, "logs")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)


logging.basicConfig(
    filename=os.path.join(LOGS_DIR, "app.log"),
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)


def main():

    logging.info("Начало работы программы")

    full_results = []
    extracted_results = []

    for number, query in enumerate(QUERIES, start=1):

        print("\n" + "=" * 60)
        print(f"Запрос {number} из {len(QUERIES)}")
        print(f"Вопрос: {query}")
        print("=" * 60)

        result = send_query(query)

        full_results.append(result)

        extracted = extract_data(result)

        extracted_results.append(extracted)

        if result["success"]:

            print("Ответ получен.")

            for answer in extracted["answer"] or []:
                print(
                    f"{answer['pod']}: "
                    f"{answer['text']}"
                )

        else:
            print("Ошибка:")
            print(result.get("error"))

    # Сохраняем полные JSON-ответы
    full_file = os.path.join(
        DATA_DIR,
        "full_results.json"
    )

    with open(
        full_file,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            full_results,
            file,
            ensure_ascii=False,
            indent=4
        )

    # Сохраняем извлечённые данные
    extracted_file = os.path.join(
        DATA_DIR,
        "extracted_results.json"
    )

    with open(
        extracted_file,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            extracted_results,
            file,
            ensure_ascii=False,
            indent=4
        )

    logging.info(
        "Полные и извлечённые результаты сохранены"
    )

    print("\n" + "=" * 60)
    print("РАБОТА ЗАВЕРШЕНА")
    print("=" * 60)

    print(f"\nПолные результаты:")
    print(full_file)

    print(f"\nИзвлечённые результаты:")
    print(extracted_file)


if __name__ == "__main__":
    main()